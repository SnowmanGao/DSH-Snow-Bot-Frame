---
name: dsh-asar-inspect
description: 确认 DSH（DeepSeek Harness）system prompt 中某段提示词对应的精确 section/context name 及其类型（静态字符串 vs 条件渲染函数），用于落地 SECTIONS_TO_DROP / CONTEXTS_TO_DROP / SECTIONS_TO_COMPACT / CONTEXT_TO_COMPACT。从反编译 <DSH>/resources/app.asar 开始。
read_when:
  - 需要确认 DSH 提示词片段的 section/context name 或类型
  - 屏蔽/裁剪 DSH system prompt（SECTIONS_TO_DROP 等）
  - 反编译 app.asar 找某段提示词的来源
---

# DSH 提示词 section/context 逆向检查

把 DSH system prompt 里可见的一段文字，对应到它的精确 `name` 与类型，决定如何裁剪。

## 步骤

1. 定位 app.asar：默认 `D:/Study_/DSHarness/resources/app.asar`，可用 `DSH_ASAR` 环境变量覆盖。
2. 按关键词搜包（结果通常是 `dsh/node_modules/@deepseek-ai/<包>/lib/index.js`）：

   ```bash
   node scripts/inspect.mjs find "关键词"
   ```

3. 定位注册行（打印关键词上下文，含 `name:` / `text:`）：

   ```bash
   node scripts/inspect.mjs section "关键词"
   ```

   需要全文时：`node scripts/inspect.mjs dump <file-path>`。

4. 找 `ctx.systemPrompt.section({ name: "..." })` 或 `ctx.systemPrompt.context({ name: "..." })`，即精确 name。
5. 判断类型：
   - `text: "字符串"` → 静态，restrict 移除工具后仍保留 → 需写 DROP。
   - `text: (context) => ...` 且工具不可见时返回 `""` → 条件渲染，restrict 后自动变空。
   - `text: (context) => ...` 但返回固定字符串 → 等同静态。
6. 落地 `src/prompt.ts`：整段删 → `*_TO_DROP`；删部分句子 → `*_TO_COMPACT`（正则 replace）。

## 已知 section/context 速查

- 身份/界面：`harness:identity`、`deployment:persona-prefix`、`harness:source`(section+context)、`app:web-surface`(section+context)、`context:file-reference`、`ui:deliverable-file-references`
- 静态 tool 段：`tool:goal`、`tool:jobs`、`tool:workflow`、`tool:bash`、`tool:pwsh`
- 条件 tool 段：`tool:read/write/edit/glob/grep/web_search/web_fetch`、`tool:subagent`
- context：`working-directory:current`、`sandbox:policy`、`approval:policy`、`tool:subagent:depth`

## asar 解析要点

- 头部：offset 0 = 头部总长（此处无用），offset 12 = json 长度；文件数据从 `16 + jsonSize` 开始。
- 每个文件的 `offset` 字段是字符串，需 `parseInt`；内容区间 `[16+jsonSize+offset, +size]`。
- 只搜 `*.js/mjs/cjs`，跳过 `*.d.ts` 与超大文件（>2MB）加速。
