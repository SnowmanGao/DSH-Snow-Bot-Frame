#!/usr/bin/env node
// DSH app.asar 提示词逆向检查脚本。
// 用法见文件末尾 help；asar 路径用环境变量 DSH_ASAR 覆盖。

import { readFileSync } from 'node:fs';

const ASAR = process.env.DSH_ASAR || 'D:/Study_/DSHarness/resources/app.asar';

// 解析 asar：头部 offset 0 = 总长(无用于此)，offset 12 = json 长度，
// 文件数据从 16 + jsonSize 开始；每个文件的 offset 是字符串，需 parseInt。
function parseAsar(asarPath) {
  const buf = readFileSync(asarPath);
  const jsonSize = buf.readUInt32LE(12);
  const header = JSON.parse(buf.subarray(16, 16 + jsonSize).toString('utf8'));
  const dataStart = 16 + jsonSize;
  const files = [];
  (function walk(node, path) {
    if (!node || !node.files) return;
    for (const [k, v] of Object.entries(node.files)) {
      const p = path ? path + '/' + k : k;
      if (v.offset !== undefined) files.push({ path: p, offset: parseInt(v.offset), size: v.size });
      walk(v, p);
    }
  })(header, '');
  return { buf, dataStart, files };
}

function content(asar, f) {
  return asar.buf.subarray(asar.dataStart + f.offset, asar.dataStart + f.offset + f.size).toString('utf8');
}

const isJs = (f) => /\.(js|mjs|cjs)$/.test(f.path) && !/\.d\.ts$/.test(f.path);

const [, , cmd, ...args] = process.argv;
const asar = parseAsar(ASAR);

if (cmd === 'find') {
  // 列出包含任一关键词的 js 文件（跳过 >2MB 加速）。
  for (const f of asar.files) {
    if (!isJs(f) || f.size > 2000000) continue;
    const c = content(asar, f);
    for (const n of args) if (c.includes(n)) { console.log(`[${n}] ${f.path} (${f.size}B)`); break; }
  }
} else if (cmd === 'dump') {
  // 打印指定文件全文。
  const f = asar.files.find((x) => x.path === args[0]);
  if (!f) { console.error('NOT FOUND:', args[0]); process.exit(1); }
  console.log(content(asar, f));
} else if (cmd === 'section') {
  // 定位关键词所在行，打印前后上下文（含 name:/text: 注册信息）。
  for (const f of asar.files) {
    if (!isJs(f) || f.size > 2000000) continue;
    const c = content(asar, f);
    if (!args.some((n) => c.includes(n))) continue;
    const lines = c.split('\n');
    for (let i = 0; i < lines.length; i++) {
      if (!args.some((n) => lines[i].includes(n))) continue;
      console.log(`\n===== ${f.path}:${i + 1} =====`);
      for (let j = Math.max(0, i - 4); j < Math.min(lines.length, i + 10); j++) console.log(`${j + 1}: ${lines[j]}`);
    }
  }
} else {
  console.log(`DSH app.asar 提示词逆向检查
用法:
  node inspect.mjs find "关键词..."     搜索含关键词的文件
  node inspect.mjs dump <file-path>     打印文件全文
  node inspect.mjs section "关键词..."  定位关键词所在行及上下文
环境变量 DSH_ASAR 覆盖 asar 路径（默认 ${ASAR}）`);
}
